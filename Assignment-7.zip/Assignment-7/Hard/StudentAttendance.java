public class StudentAttendance {
    private String roll;
    private String name;
    private String date;
    private String status;

    public StudentAttendance(String roll, String name, String date, String status) {
        this.roll = roll;
        this.name = name;
        this.date = date;
        this.status = status;
    }

    // Getters and Setters (optional)
}

