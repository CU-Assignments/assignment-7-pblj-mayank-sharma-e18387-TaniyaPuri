import java.io.*;
import javax.servlet.*;
import javax.servlet.http.*;
import java.sql.*;

public class AttendanceServlet extends HttpServlet {
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String roll = request.getParameter("roll");
        String name = request.getParameter("name");
        String date = request.getParameter("date");
        String status = request.getParameter("status");

        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            Connection con = DriverManager.getConnection(
                "jdbc:mysql://localhost:3306/yourDatabase", "root", "yourPassword");

            PreparedStatement pst = con.prepareStatement(
                "INSERT INTO attendance(roll, name, date, status) VALUES (?, ?, ?, ?)");
            pst.setString(1, roll);
            pst.setString(2, name);
            pst.setString(3, date);
            pst.setString(4, status);
            pst.executeUpdate();

            RequestDispatcher rd = request.getRequestDispatcher("attendance-success.jsp");
            rd.forward(request, response);
        } catch (Exception e) {
            response.getWriter().println("Error: " + e.getMessage());
        }
    }
}

